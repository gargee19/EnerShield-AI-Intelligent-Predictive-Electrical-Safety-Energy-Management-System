# ENERSHIELD OS — Setup Guide

## Project Structure

```
enershield-os/
├── backend/
│   ├── main.py              ← FastAPI entry point
│   ├── requirements.txt
│   ├── api/routes.py        ← All REST endpoints
│   ├── ai/engine.py         ← AI engine: anomaly detection, health scoring
│   └── db/database.py       ← SQLite database layer
├── frontend/
│   ├── pages/index.tsx      ← Cinematic dashboard
│   ├── hooks/useLiveData.ts ← REST polling hook
│   ├── styles/globals.css   ← Cyber aesthetic styles
│   ├── package.json
│   ├── next.config.js
│   └── tailwind.config.js
└── firmware/
    └── enershield_esp32.ino ← ESP32 Arduino code
```

---

## 1. Backend Setup

```bash
cd enershield-os/backend
pip install -r requirements.txt
python main.py
```

Backend runs at: http://0.0.0.0:8000

### API Endpoints

| Method | Endpoint        | Description                    |
|--------|-----------------|--------------------------------|
| POST   | /api/data       | ESP32 sends telemetry          |
| GET    | /api/live       | Frontend polls live data       |
| GET    | /api/ai/status  | AI analysis                    |
| GET    | /api/relay      | ESP32 gets relay commands      |
| POST   | /api/relay      | Dashboard overrides relays     |
| GET    | /api/oled       | ESP32 gets OLED lines          |
| GET    | /api/events     | Event timeline                 |
| GET    | /health         | Backend health check           |

---

## 2. Frontend Setup

```bash
cd enershield-os/frontend
npm install
npm run dev
```

Dashboard runs at: http://localhost:3000

To point at a different backend:
```bash
NEXT_PUBLIC_API_URL=http://10.184.175.22:8000 npm run dev
```

---

## 3. ESP32 Firmware

### Required Arduino Libraries

Install via Arduino IDE Library Manager:
- `ArduinoJson` by Benoit Blanchon (v6.x)
- `DHT sensor library` by Adafruit
- `Adafruit SSD1306` by Adafruit
- `Adafruit GFX Library` by Adafruit

### Board

- Select: **ESP32 Dev Module**
- Upload Speed: 115200

### Key Configuration (top of .ino)

```cpp
const char* WIFI_SSID   = "ESP";
const char* WIFI_PASS   = "12345678";
const char* BACKEND_URL = "http://10.184.175.22:8000";
```

### ACS712 Calibration

Adjust `ACS712_SENSITIVITY` and `ACS712_MIDPOINT` for your exact module:
- 5A module: 185 mV/A
- 20A module: 100 mV/A
- 30A module: 66 mV/A

### ZMPT101B Calibration

Adjust `ZMPT_CALIBRATION` factor to match your transformer ratio against a reference voltmeter.

---

## 4. Demo Script

### Demo 1 — Normal Learning
- Power on, watch dashboard go LEARNING → HEALTHY
- AI builds baseline for all sensors

### Demo 2 — Motor Vibration Anomaly
- Gently hold/disturb the motor
- Dashboard shows vibration spike, Z-score rise
- Maintenance recommendation appears

### Demo 3 — Fan Anomaly
- Insert paper into fan blades
- Dashboard detects rotational instability
- "Airflow obstruction" explanation appears

### Demo 4 — Overload (Bulb)
- Apply additional current load via bulb circuit
- Current rises, overload warning triggers
- Bulb relay auto-disconnects at critical threshold
- "AUTONOMOUS PROTECTION ACTIVATED" banner

### Demo 5 — Gas + Thermal Hazard
- Expose MQ2 to lighter gas or smoke
- Expose DHT11 to heat source
- Dashboard shows CRITICAL alerts
- All relays shut down, buzzer activates

### Demo 6 — Electrical Efficiency
- Monitor Estimated Power Factor card
- Vary loads to show PF fluctuation
- AI explains efficiency degradation

---

## 5. AI Engine Overview

The AI engine (`ai/engine.py`) implements:

- **Rolling Statistics**: Welford's online algorithm for mean/std
- **Z-Score Anomaly Detection**: Per-sensor anomaly scoring
- **Adaptive Thresholds**: Learns normal operating range
- **Health Score**: 0–100, degrades with anomalies
- **Risk Score**: 0–100, combines all threat signals
- **Relay Intelligence**: Autonomous protection logic
- **Explainable AI**: Human-readable diagnosis strings
- **Electrical Efficiency**: PF estimation from V/I stability

---

## 6. Network Architecture

```
ESP32
  │── POST /api/data  (1 Hz)  ──► FastAPI Backend ──► AI Engine ──► SQLite DB
  │◄── GET /api/relay (1 Hz) ──┘
  └── GET /api/oled   (0.5 Hz) ─┘

Next.js Dashboard
  └── GET /api/live   (1 Hz) ──► FastAPI Backend ──► Live Response
```

All communication is HTTP REST polling. No WebSockets.
