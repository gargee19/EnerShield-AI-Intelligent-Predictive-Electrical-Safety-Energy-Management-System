/*
 * ╔══════════════════════════════════════════════════════════════╗
 * ║           ENERSHIELD OS — ESP32 FIRMWARE v1.0               ║
 * ║   AI-Powered Predictive Infrastructure Operating System     ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 *  Sensors : DHT11, MQ2, ACS712, ZMPT101B, SW420
 *  Outputs : 3x Relay, OLED, Buzzer
 *  Backend : FastAPI REST @ http://10.184.175.22:8000
 */

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <DHT.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ─── WiFi ────────────────────────────────────────────────────────────────────
const char* WIFI_SSID     = "ESP";
const char* WIFI_PASS     = "12345678";
const char* BACKEND_URL   = "http://10.184.175.22:8000";

// ─── Pin Definitions ─────────────────────────────────────────────────────────
#define LED_BUILTIN       2
#define PIN_DHT           4
#define PIN_SW420         27
#define PIN_ZMPT101B      33
#define PIN_GAS           34
#define PIN_BUZZER        25
#define PIN_ACS712        32
#define PIN_RELAY_MOTOR   18
#define PIN_RELAY_FAN     26
#define PIN_RELAY_BULB    23
#define PIN_OLED_SDA      21
#define PIN_OLED_SCL      22

// ─── OLED ─────────────────────────────────────────────────────────────────────
#define SCREEN_WIDTH      128
#define SCREEN_HEIGHT     64
#define OLED_RESET        -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ─── DHT ──────────────────────────────────────────────────────────────────────
#define DHTTYPE DHT11
DHT dht(PIN_DHT, DHTTYPE);

// ─── ACS712 Config ────────────────────────────────────────────────────────────
// ACS712-5A: sensitivity = 185 mV/A, midpoint = VCC/2 ≈ 1.65V (3.3V supply)
// ESP32 ADC: 12-bit, 0–4095, 0–3.3V ref
#define ACS712_SENSITIVITY   0.185f    // V/A for 5A module
#define ACS712_MIDPOINT      1650      // mV midpoint (3300/2)
#define ADC_REF_MV           3300
#define ADC_RESOLUTION       4095

// ─── ZMPT101B Config ──────────────────────────────────────────────────────────
// Returns RMS voltage estimate via peak detection
#define ZMPT_SAMPLES         500
#define ZMPT_CALIBRATION     0.706f   // Calibrate to your transformer ratio

// ─── Timing ───────────────────────────────────────────────────────────────────
#define TELEMETRY_INTERVAL   1000     // ms between POST requests
#define RELAY_POLL_INTERVAL  1000     // ms between relay GET
#define OLED_UPDATE_INTERVAL 2000     // ms between OLED GET

unsigned long lastTelemetry  = 0;
unsigned long lastRelayPoll  = 0;
unsigned long lastOledUpdate = 0;

// ─── State ────────────────────────────────────────────────────────────────────
struct SystemState {
  float    temperature     = 25.0f;
  float    humidity        = 50.0f;
  float    gas_level       = 100.0f;
  float    current_amps    = 0.0f;
  float    voltage_rms     = 220.0f;
  int      vibration       = 0;
  int      relay_motor     = 1;
  int      relay_fan       = 1;
  int      relay_bulb      = 1;
  bool     buzzer_active   = false;
  String   ai_status       = "LEARNING";
  float    health_score    = 100.0f;
  float    risk_score      = 0.0f;
  String   oled_line1      = "EnerShield OS";
  String   oled_line2      = "Starting...";
  String   oled_line3      = "";
  String   oled_line4      = "";
} state;

// ─── Relay helper (ACTIVE LOW) ────────────────────────────────────────────────
void setRelay(int pin, int value) {
  // value=1 means ON, relay ACTIVE LOW → write LOW to turn ON
  digitalWrite(pin, value ? LOW : HIGH);
}

// ─── Read ACS712 Current ─────────────────────────────────────────────────────
float readCurrentAmps() {
  long sum = 0;
  int samples = 200;
  for (int i = 0; i < samples; i++) {
    sum += analogRead(PIN_ACS712);
    delayMicroseconds(100);
  }
  float avg_raw = (float)sum / samples;
  float voltage_mv = (avg_raw / ADC_RESOLUTION) * ADC_REF_MV;
  float offset_mv  = voltage_mv - ACS712_MIDPOINT;
  float amps       = offset_mv / 1000.0f / ACS712_SENSITIVITY;
  return fabs(amps);  // Return magnitude
}

// ─── Read ZMPT101B Voltage ────────────────────────────────────────────────────
float readVoltageRMS() {
  long sum_sq = 0;
  for (int i = 0; i < ZMPT_SAMPLES; i++) {
    int raw = analogRead(PIN_ZMPT101B);
    int centered = raw - 2048;  // Remove DC offset (12-bit midpoint)
    sum_sq += (long)centered * centered;
    delayMicroseconds(40);  // ~500 samples across ~20ms (one 50Hz cycle)
  }
  float rms_raw = sqrt((float)sum_sq / ZMPT_SAMPLES);
  float rms_mv  = (rms_raw / ADC_RESOLUTION) * ADC_REF_MV;
  // Scale to mains voltage using calibration factor
  return rms_mv * ZMPT_CALIBRATION;
}

// ─── OLED Display ─────────────────────────────────────────────────────────────
void updateOLEDLocal() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("EnerShield OS");
  display.drawLine(0, 9, 127, 9, SSD1306_WHITE);
  display.setCursor(0, 12);
  display.println(state.oled_line1);
  display.setCursor(0, 24);
  display.println(state.oled_line2);
  display.setCursor(0, 36);
  display.println(state.oled_line3);
  display.setCursor(0, 48);
  display.println(state.oled_line4);
  display.display();
}

// ─── POST Telemetry ───────────────────────────────────────────────────────────
void postTelemetry() {
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  http.begin(String(BACKEND_URL) + "/api/data");
  http.addHeader("Content-Type", "application/json");

  StaticJsonDocument<256> doc;
  doc["temperature"] = state.temperature;
  doc["gas_level"]   = state.gas_level;
  doc["current"]     = state.current_amps;
  doc["voltage"]     = state.voltage_rms;
  doc["vibration"]   = state.vibration;
  doc["relay_motor"] = state.relay_motor;
  doc["relay_fan"]   = state.relay_fan;
  doc["relay_bulb"]  = state.relay_bulb;

  String body;
  serializeJson(doc, body);

  int code = http.POST(body);
  if (code == 200) {
    String resp = http.getString();
    StaticJsonDocument<256> resp_doc;
    if (!deserializeJson(resp_doc, resp)) {
      const char* ai_status = resp_doc["ai_status"] | "LEARNING";
      state.ai_status   = String(ai_status);
      state.health_score = resp_doc["health_score"] | 100.0f;
      bool autonomous    = resp_doc["autonomous"] | false;

      // Handle relay commands from response
      if (resp_doc.containsKey("relay_commands")) {
        state.relay_motor = resp_doc["relay_commands"]["motor"] | 1;
        state.relay_fan   = resp_doc["relay_commands"]["fan"] | 1;
        state.relay_bulb  = resp_doc["relay_commands"]["bulb"] | 1;
        setRelay(PIN_RELAY_MOTOR, state.relay_motor);
        setRelay(PIN_RELAY_FAN,   state.relay_fan);
        setRelay(PIN_RELAY_BULB,  state.relay_bulb);
      }

      // Buzzer on critical
      if (state.ai_status == "CRITICAL") {
        tone(PIN_BUZZER, 1000, 200);
      }

      // OLED status update
      state.oled_line1 = "H:" + String((int)state.health_score) + "% " + state.ai_status;
      state.oled_line2 = "T:" + String(state.temperature, 1) + "C I:" + String(state.current_amps, 2) + "A";
      state.oled_line3 = "V:" + String(state.voltage_rms, 0) + "V Gas:" + String((int)state.gas_level);
      updateOLEDLocal();
    }
  }
  http.end();
}

// ─── GET Relay Commands ───────────────────────────────────────────────────────
void fetchRelayCommands() {
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  http.begin(String(BACKEND_URL) + "/api/relay");
  int code = http.GET();
  if (code == 200) {
    String resp = http.getString();
    StaticJsonDocument<256> doc;
    if (!deserializeJson(doc, resp)) {
      state.relay_motor = doc["relay_motor"] | 1;
      state.relay_fan   = doc["relay_fan"]   | 1;
      state.relay_bulb  = doc["relay_bulb"]  | 1;
      setRelay(PIN_RELAY_MOTOR, state.relay_motor);
      setRelay(PIN_RELAY_FAN,   state.relay_fan);
      setRelay(PIN_RELAY_BULB,  state.relay_bulb);
    }
  }
  http.end();
}

// ─── GET OLED Content ─────────────────────────────────────────────────────────
void fetchOLEDContent() {
  if (WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  http.begin(String(BACKEND_URL) + "/api/oled");
  int code = http.GET();
  if (code == 200) {
    String resp = http.getString();
    StaticJsonDocument<256> doc;
    if (!deserializeJson(doc, resp)) {
      state.oled_line1 = String((const char*)doc["line1"] | "");
      state.oled_line2 = String((const char*)doc["line2"] | "");
      state.oled_line3 = String((const char*)doc["line3"] | "");
      state.oled_line4 = String((const char*)doc["line4"] | "");
      updateOLEDLocal();
    }
  }
  http.end();
}

// ─── WiFi Connect ─────────────────────────────────────────────────────────────
void connectWiFi() {
  display.clearDisplay();
  display.setCursor(0, 0);
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.println("EnerShield OS");
  display.println("Connecting WiFi...");
  display.println(WIFI_SSID);
  display.display();

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  int tries = 0;
  while (WiFi.status() != WL_CONNECTED && tries < 30) {
    delay(500);
    Serial.print(".");
    tries++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n[WiFi] Connected: " + WiFi.localIP().toString());
    display.println("CONNECTED!");
    display.println(WiFi.localIP().toString());
    display.display();
    delay(1500);
  } else {
    Serial.println("\n[WiFi] Failed — running offline");
    display.println("OFFLINE MODE");
    display.display();
    delay(1000);
  }
}

// ─── Setup ────────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  Serial.println("[EnerShield OS] Booting...");

  // Init pins
  pinMode(LED_BUILTIN,    OUTPUT);
  pinMode(PIN_SW420,      INPUT);
  pinMode(PIN_BUZZER,     OUTPUT);
  pinMode(PIN_RELAY_MOTOR, OUTPUT);
  pinMode(PIN_RELAY_FAN,   OUTPUT);
  pinMode(PIN_RELAY_BULB,  OUTPUT);

  // All relays OFF initially (active LOW → HIGH = off)
  digitalWrite(PIN_RELAY_MOTOR, HIGH);
  digitalWrite(PIN_RELAY_FAN,   HIGH);
  digitalWrite(PIN_RELAY_BULB,  HIGH);

  // DHT
  dht.begin();

  // OLED
  Wire.begin(PIN_OLED_SDA, PIN_OLED_SCL);
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("[OLED] INIT FAILED");
  } else {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.println("EnerShield OS v1.0");
    display.println("AI Infrastructure OS");
    display.display();
    delay(1000);
  }

  connectWiFi();

  // Enable relays (turn ON loads)
  setRelay(PIN_RELAY_MOTOR, 1);
  setRelay(PIN_RELAY_FAN,   1);
  setRelay(PIN_RELAY_BULB,  1);
  state.relay_motor = 1;
  state.relay_fan   = 1;
  state.relay_bulb  = 1;

  // Boot tone
  tone(PIN_BUZZER, 880, 100);
  delay(150);
  tone(PIN_BUZZER, 1100, 100);

  Serial.println("[EnerShield OS] System Ready");
}

// ─── Main Loop ────────────────────────────────────────────────────────────────
void loop() {
  unsigned long now = millis();

  // ── Read all sensors ──
  // DHT11
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  if (!isnan(t)) state.temperature = t;
  if (!isnan(h)) state.humidity    = h;

  // Gas (MQ2) — raw ADC 0–4095
  state.gas_level = analogRead(PIN_GAS);

  // Vibration SW420
  state.vibration = digitalRead(PIN_SW420);

  // Current ACS712
  state.current_amps = readCurrentAmps();

  // Voltage ZMPT101B
  state.voltage_rms = readVoltageRMS();

  // ── Serial debug ──
  Serial.printf("[T=%.1f°C H=%.0f%% Gas=%.0f Vib=%d I=%.3fA V=%.1fV Status=%s]\n",
    state.temperature, state.humidity, state.gas_level,
    state.vibration, state.current_amps, state.voltage_rms,
    state.ai_status.c_str()
  );

  // ── POST telemetry ──
  if (now - lastTelemetry >= TELEMETRY_INTERVAL) {
    lastTelemetry = now;
    digitalWrite(LED_BUILTIN, HIGH);
    postTelemetry();
    digitalWrite(LED_BUILTIN, LOW);
  }

  // ── Poll relay commands ──
  if (now - lastRelayPoll >= RELAY_POLL_INTERVAL) {
    lastRelayPoll = now;
    fetchRelayCommands();
  }

  // ── Update OLED from backend ──
  if (now - lastOledUpdate >= OLED_UPDATE_INTERVAL) {
    lastOledUpdate = now;
    fetchOLEDContent();
  }

  delay(50);  // Small yield
}
