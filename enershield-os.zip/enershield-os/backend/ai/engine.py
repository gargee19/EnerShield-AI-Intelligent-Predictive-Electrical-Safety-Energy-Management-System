"""
EnerShield OS — AI Intelligence Engine
Pattern Learning | Anomaly Detection | Predictive Maintenance | Explainable AI
"""
import time
import math
from collections import deque
from typing import Optional

# ─── Rolling Window Parameters ───────────────────────────────────────────────
LEARNING_WINDOW     = 60     # samples to build baseline
ANOMALY_WINDOW      = 20     # recent samples for z-score
VIBRATION_WINDOW    = 30
CURRENT_WINDOW      = 30
TEMP_WINDOW         = 40
GAS_WINDOW          = 30

# ─── Thresholds ───────────────────────────────────────────────────────────────
VIBRATION_ZSCORE_WARN    = 2.0
VIBRATION_ZSCORE_CRIT    = 3.5
CURRENT_ZSCORE_WARN      = 2.0
CURRENT_ZSCORE_CRIT      = 3.2
CURRENT_ABS_OVERLOAD     = 4.5   # Amps
TEMP_WARN                = 40.0  # °C
TEMP_CRIT                = 55.0
GAS_WARN                 = 300   # raw ADC units
GAS_CRIT                 = 600
VOLTAGE_DIP_WARN         = 200   # Volts
VOLTAGE_SURGE_WARN       = 245


class RollingStats:
    """Online mean + std using Welford's algorithm"""
    def __init__(self, maxlen=60):
        self._buf  = deque(maxlen=maxlen)
        self._n    = 0
        self._mean = 0.0
        self._M2   = 0.0

    def update(self, x: float):
        self._buf.append(x)
        self._n += 1
        delta  = x - self._mean
        self._mean += delta / self._n
        delta2 = x - self._mean
        self._M2 += delta * delta2

    @property
    def mean(self): return self._mean

    @property
    def std(self):
        if self._n < 2: return 1.0
        return math.sqrt(self._M2 / (self._n - 1))

    @property
    def count(self): return self._n

    def zscore(self, x: float) -> float:
        s = self.std
        if s < 1e-6: return 0.0
        return abs(x - self.mean) / s

    def is_ready(self): return self._n >= LEARNING_WINDOW


# ─── Global AI State ──────────────────────────────────────────────────────────
_vibration_stats  = RollingStats(VIBRATION_WINDOW)
_current_stats    = RollingStats(CURRENT_WINDOW)
_temp_stats       = RollingStats(TEMP_WINDOW)
_gas_stats        = RollingStats(GAS_WINDOW)
_voltage_stats    = RollingStats(30)

_vibration_history = deque(maxlen=200)
_current_history   = deque(maxlen=200)
_temp_history      = deque(maxlen=200)
_gas_history       = deque(maxlen=200)
_sample_count      = 0

_last_analysis: dict = {}


def _clamp(v, lo=0.0, hi=100.0): return max(lo, min(hi, v))


def analyze(telemetry: dict) -> dict:
    global _sample_count, _last_analysis

    ts          = telemetry.get("timestamp", time.time())
    temperature = float(telemetry.get("temperature", 25.0))
    gas_level   = float(telemetry.get("gas_level", 100))
    current     = float(telemetry.get("current", 0.0))
    voltage     = float(telemetry.get("voltage", 220.0))
    vibration   = int(telemetry.get("vibration", 0))

    _sample_count += 1

    # ── Update rolling stats ──
    _vibration_stats.update(float(vibration))
    _current_stats.update(current)
    _temp_stats.update(temperature)
    _gas_stats.update(gas_level)
    _voltage_stats.update(voltage)

    # Histories
    _vibration_history.append(vibration)
    _current_history.append(current)
    _temp_history.append(temperature)
    _gas_history.append(gas_level)

    learning_complete = _vibration_stats.is_ready()
    learning_progress = min(100, int(_sample_count / LEARNING_WINDOW * 100))

    # ── Z-scores ──
    vib_z  = _vibration_stats.zscore(float(vibration))
    cur_z  = _current_stats.zscore(current)
    temp_z = _temp_stats.zscore(temperature)
    gas_z  = _gas_stats.zscore(gas_level)

    # ─────────────────────────────────────────
    # ANOMALY ANALYSIS
    # ─────────────────────────────────────────
    anomalies   = []
    explanations = []
    risk_score  = 0.0
    health_score = 100.0

    # ── Vibration Analysis ──
    vib_anomaly = "normal"
    if learning_complete:
        if vib_z > VIBRATION_ZSCORE_CRIT:
            vib_anomaly = "critical"
            risk_score  += 35
            health_score -= 30
            anomalies.append("VIBRATION_CRITICAL")
            explanations.append("Severe mechanical vibration anomaly detected — possible shaft imbalance or bearing failure.")
        elif vib_z > VIBRATION_ZSCORE_WARN:
            vib_anomaly = "warning"
            risk_score  += 15
            health_score -= 12
            anomalies.append("VIBRATION_WARNING")
            explanations.append("Vibration pattern deviating from learned baseline — mechanical stress building.")

    # ── Current Analysis ──
    cur_anomaly = "normal"
    if current > CURRENT_ABS_OVERLOAD:
        cur_anomaly = "critical"
        risk_score  += 40
        health_score -= 35
        anomalies.append("OVERLOAD_CRITICAL")
        explanations.append(f"Current overload at {current:.2f}A — electrical stress exceeds safe threshold. Autonomous protection may activate.")
    elif learning_complete and cur_z > CURRENT_ZSCORE_CRIT:
        cur_anomaly = "critical"
        risk_score  += 30
        health_score -= 25
        anomalies.append("CURRENT_SPIKE")
        explanations.append("Abnormal current spike detected — possible inductive load surge or short circuit developing.")
    elif learning_complete and cur_z > CURRENT_ZSCORE_WARN:
        cur_anomaly = "warning"
        risk_score  += 12
        health_score -= 10
        anomalies.append("CURRENT_ANOMALY")
        explanations.append("Current consumption deviating from baseline — load behavior unstable.")

    # ── Temperature Analysis ──
    temp_anomaly = "normal"
    if temperature >= TEMP_CRIT:
        temp_anomaly = "critical"
        risk_score   += 35
        health_score -= 30
        anomalies.append("THERMAL_CRITICAL")
        explanations.append(f"Critical thermal condition at {temperature:.1f}°C — fire hazard probability rising. Immediate intervention required.")
    elif temperature >= TEMP_WARN:
        temp_anomaly = "warning"
        risk_score   += 18
        health_score -= 14
        anomalies.append("THERMAL_WARNING")
        explanations.append(f"Elevated temperature at {temperature:.1f}°C — thermal stress increasing on electrical components.")

    # ── Gas Analysis ──
    gas_anomaly = "normal"
    if gas_level >= GAS_CRIT:
        gas_anomaly = "critical"
        risk_score  += 45
        health_score -= 40
        anomalies.append("GAS_CRITICAL")
        explanations.append(f"Dangerous gas concentration detected ({gas_level:.0f}) — fire/explosion hazard. Emergency protection activated.")
    elif gas_level >= GAS_WARN:
        gas_anomaly = "warning"
        risk_score  += 20
        health_score -= 16
        anomalies.append("GAS_WARNING")
        explanations.append(f"Elevated gas level ({gas_level:.0f}) detected — ventilation or leak investigation required.")

    # ── Voltage Analysis ──
    volt_anomaly = "normal"
    if voltage < VOLTAGE_DIP_WARN and voltage > 0:
        volt_anomaly = "warning"
        risk_score   += 10
        health_score -= 8
        anomalies.append("VOLTAGE_DIP")
        explanations.append(f"Voltage dip detected at {voltage:.1f}V — possible supply instability or overloaded circuit.")
    elif voltage > VOLTAGE_SURGE_WARN:
        volt_anomaly = "warning"
        risk_score   += 10
        health_score -= 8
        anomalies.append("VOLTAGE_SURGE")
        explanations.append(f"Voltage surge at {voltage:.1f}V — risk of insulation breakdown or equipment damage.")

    # ─────────────────────────────────────────
    # RELAY INTELLIGENCE
    # ─────────────────────────────────────────
    relay_motor = 1  # 1 = ON (active low relay: LOW=ON)
    relay_fan   = 1
    relay_bulb  = 1
    autonomous  = False
    relay_reason = ""

    if "GAS_CRITICAL" in anomalies or "THERMAL_CRITICAL" in anomalies:
        relay_motor = 0
        relay_fan   = 0
        relay_bulb  = 0
        autonomous  = True
        relay_reason = "EMERGENCY SHUTDOWN — Gas/Thermal hazard detected. All loads isolated."
    elif "OVERLOAD_CRITICAL" in anomalies:
        relay_bulb  = 0
        autonomous  = True
        relay_reason = "OVERLOAD PROTECTION — Bulb load disconnected to prevent electrical damage."
    elif "VIBRATION_CRITICAL" in anomalies:
        relay_motor = 0
        autonomous  = True
        relay_reason = "PREDICTIVE PROTECTION — Motor isolated due to critical vibration anomaly."

    # ─────────────────────────────────────────
    # ELECTRICAL EFFICIENCY (Simplified PF Estimate)
    # ─────────────────────────────────────────
    recent_v = list(_voltage_stats._buf)[-10:] if len(_voltage_stats._buf) >= 10 else list(_voltage_stats._buf)
    recent_i = list(_current_stats._buf)[-10:] if len(_current_stats._buf) >= 10 else list(_current_stats._buf)
    
    v_var = _safe_variance(recent_v)
    i_var = _safe_variance(recent_i)
    
    apparent_power = voltage * current if current > 0 else 0
    # Simplified efficiency: reduce PF estimate as variance increases
    stability_penalty = min(0.3, (v_var / (voltage**2 + 1e-6)) * 50 + (i_var / (current**2 + 1e-6)) * 20) if current > 0 else 0
    est_pf = max(0.5, min(0.99, 0.92 - stability_penalty))
    est_active_power = apparent_power * est_pf

    electrical_efficiency = {
        "estimated_pf": round(est_pf, 3),
        "apparent_power_va": round(apparent_power, 2),
        "estimated_active_power_w": round(est_active_power, 2),
        "efficiency_label": _pf_label(est_pf),
        "v_stability": round(max(0, 1 - v_var / 100), 3),
        "i_stability": round(max(0, 1 - i_var / 1), 3),
    }

    # ─────────────────────────────────────────
    # PREDICTIVE MAINTENANCE
    # ─────────────────────────────────────────
    maintenance_flags = []
    if "VIBRATION_WARNING" in anomalies or "VIBRATION_CRITICAL" in anomalies:
        maintenance_flags.append({"component": "Motor/Fan", "issue": "Mechanical vibration anomaly", "priority": "HIGH", "action": "Inspect bearings, shaft alignment, and mounting"})
    if "OVERLOAD_CRITICAL" in anomalies or "CURRENT_SPIKE" in anomalies:
        maintenance_flags.append({"component": "Electrical Circuit", "issue": "Overcurrent condition", "priority": "CRITICAL", "action": "Check wiring, fuses, and load distribution"})
    if "THERMAL_WARNING" in anomalies or "THERMAL_CRITICAL" in anomalies:
        maintenance_flags.append({"component": "Thermal Management", "issue": "Overheating detected", "priority": "HIGH", "action": "Improve ventilation, check insulation, reduce load"})
    if "GAS_WARNING" in anomalies or "GAS_CRITICAL" in anomalies:
        maintenance_flags.append({"component": "Environment", "issue": "Gas/smoke contamination", "priority": "CRITICAL", "action": "Evacuate area, identify leak source, ventilate"})

    # ─────────────────────────────────────────
    # OVERALL STATUS
    # ─────────────────────────────────────────
    risk_score  = _clamp(risk_score, 0, 100)
    health_score = _clamp(health_score, 0, 100)

    if risk_score >= 60:
        overall_status = "CRITICAL"
    elif risk_score >= 30:
        overall_status = "WARNING"
    elif risk_score >= 10:
        overall_status = "CAUTION"
    else:
        overall_status = "HEALTHY"

    if not learning_complete:
        explanations = [f"System learning baseline behavior... {learning_progress}% complete. Normal infrastructure operation observed."]
        overall_status = "LEARNING"

    primary_explanation = explanations[0] if explanations else "All parameters within learned safe thresholds. Infrastructure operating normally."

    result = {
        "timestamp": ts,
        "sample_count": _sample_count,
        "learning_complete": learning_complete,
        "learning_progress": learning_progress,

        "overall_status": overall_status,
        "health_score": round(health_score, 1),
        "risk_score": round(risk_score, 1),

        "anomalies": anomalies,
        "primary_explanation": primary_explanation,
        "all_explanations": explanations,

        "components": {
            "vibration": {
                "status": vib_anomaly,
                "zscore": round(vib_z, 2),
                "baseline_mean": round(_vibration_stats.mean, 2),
                "baseline_std": round(_vibration_stats.std, 2),
                "current_value": vibration,
            },
            "current": {
                "status": cur_anomaly,
                "zscore": round(cur_z, 2),
                "baseline_mean": round(_current_stats.mean, 3),
                "baseline_std": round(_current_stats.std, 3),
                "current_value": round(current, 3),
            },
            "temperature": {
                "status": temp_anomaly,
                "zscore": round(temp_z, 2),
                "current_value": round(temperature, 1),
            },
            "gas": {
                "status": gas_anomaly,
                "zscore": round(gas_z, 2),
                "current_value": round(gas_level, 0),
            },
            "voltage": {
                "status": volt_anomaly,
                "current_value": round(voltage, 1),
            },
        },

        "relay_commands": {
            "motor": relay_motor,
            "fan": relay_fan,
            "bulb": relay_bulb,
        },
        "autonomous_protection": autonomous,
        "relay_reason": relay_reason,

        "electrical_efficiency": electrical_efficiency,

        "maintenance_flags": maintenance_flags,

        "baselines": {
            "vibration_mean": round(_vibration_stats.mean, 2),
            "current_mean": round(_current_stats.mean, 3),
            "temp_mean": round(_temp_stats.mean, 1),
            "gas_mean": round(_gas_stats.mean, 0),
        }
    }

    _last_analysis = result
    return result


def get_last_analysis() -> dict:
    return _last_analysis


def _safe_variance(data):
    if len(data) < 2: return 0.0
    mean = sum(data) / len(data)
    return sum((x - mean) ** 2 for x in data) / len(data)


def _pf_label(pf: float) -> str:
    if pf >= 0.95: return "Excellent"
    if pf >= 0.88: return "Good"
    if pf >= 0.78: return "Fair"
    return "Poor"
