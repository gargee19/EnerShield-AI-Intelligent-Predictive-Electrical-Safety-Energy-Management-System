"""
EnerShield OS — API Routes
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import time

from db.database import (
    insert_telemetry, get_latest_telemetry,
    get_relay_commands, set_relay_commands,
    log_event, get_recent_events
)
from ai.engine import analyze, get_last_analysis

router = APIRouter()

# ─── Latest telemetry cache ───────────────────────────────────────────────────
_latest_telemetry: dict = {}
_latest_ai_analysis: dict = {}


# ─── Models ───────────────────────────────────────────────────────────────────
class TelemetryPayload(BaseModel):
    temperature: Optional[float] = 25.0
    gas_level: Optional[float] = 100.0
    current: Optional[float] = 0.0
    voltage: Optional[float] = 220.0
    vibration: Optional[int] = 0
    relay_motor: Optional[int] = 1
    relay_fan: Optional[int] = 1
    relay_bulb: Optional[int] = 1


class RelayOverride(BaseModel):
    relay_motor: int = 1
    relay_fan: int = 1
    relay_bulb: int = 1


# ─── POST /api/data — ESP32 sends telemetry ───────────────────────────────────
@router.post("/api/data")
def receive_telemetry(payload: TelemetryPayload):
    global _latest_telemetry, _latest_ai_analysis

    data = payload.dict()
    data["timestamp"] = time.time()

    # Store to DB
    insert_telemetry(data)

    # Run AI analysis
    analysis = analyze(data)
    _latest_telemetry = data
    _latest_ai_analysis = analysis

    # Auto-update relays if autonomous protection triggered
    if analysis.get("autonomous_protection"):
        rc = analysis["relay_commands"]
        set_relay_commands(rc["motor"], rc["fan"], rc["bulb"], source="ai_auto")
        log_event(
            "AUTONOMOUS_PROTECTION",
            "CRITICAL",
            analysis.get("relay_reason", ""),
            {"anomalies": analysis.get("anomalies", [])}
        )

    # Log significant events
    for anomaly in analysis.get("anomalies", []):
        if "CRITICAL" in anomaly:
            log_event(anomaly, "CRITICAL", analysis.get("primary_explanation", ""), {})
        elif "WARNING" in anomaly:
            log_event(anomaly, "WARNING", analysis.get("primary_explanation", ""), {})

    return {
        "status": "ok",
        "ai_status": analysis.get("overall_status"),
        "health_score": analysis.get("health_score"),
        "relay_commands": analysis.get("relay_commands"),
        "autonomous": analysis.get("autonomous_protection", False),
    }


# ─── GET /api/live — Frontend polls live data ─────────────────────────────────
@router.get("/api/live")
def get_live_data():
    history = get_latest_telemetry(n=120)
    analysis = get_last_analysis()

    return {
        "telemetry": _latest_telemetry,
        "ai": analysis,
        "history": history[-60:] if history else [],
        "timestamp": time.time(),
    }


# ─── GET /api/ai/status — AI analysis endpoint ────────────────────────────────
@router.get("/api/ai/status")
def get_ai_status():
    analysis = get_last_analysis()
    if not analysis:
        return {"status": "no_data", "message": "Awaiting first telemetry packet"}
    return analysis


# ─── GET /api/relay — ESP32 fetches relay commands ───────────────────────────
@router.get("/api/relay")
def get_relay():
    cmds = get_relay_commands()
    analysis = get_last_analysis()

    # If autonomous protection is active, override DB commands
    if analysis and analysis.get("autonomous_protection"):
        rc = analysis["relay_commands"]
        return {
            "relay_motor": rc["motor"],
            "relay_fan": rc["fan"],
            "relay_bulb": rc["bulb"],
            "source": "ai_autonomous",
            "message": analysis.get("relay_reason", ""),
        }

    return {
        "relay_motor": cmds.get("relay_motor", 1),
        "relay_fan": cmds.get("relay_fan", 1),
        "relay_bulb": cmds.get("relay_bulb", 1),
        "source": cmds.get("source", "manual"),
        "message": "",
    }


# ─── POST /api/relay — Dashboard overrides relays ────────────────────────────
@router.post("/api/relay")
def override_relay(payload: RelayOverride):
    set_relay_commands(
        payload.relay_motor,
        payload.relay_fan,
        payload.relay_bulb,
        source="dashboard"
    )
    log_event("RELAY_OVERRIDE", "INFO",
              f"Dashboard manual relay override: Motor={payload.relay_motor} Fan={payload.relay_fan} Bulb={payload.relay_bulb}", {})
    return {"status": "ok", "applied": payload.dict()}


# ─── GET /api/oled — ESP32 fetches OLED display lines ────────────────────────
@router.get("/api/oled")
def get_oled():
    analysis = get_last_analysis()
    tel = _latest_telemetry

    if not analysis:
        return {
            "line1": "EnerShield OS",
            "line2": "INITIALIZING...",
            "line3": "Waiting for data",
            "line4": ""
        }

    status  = analysis.get("overall_status", "LEARNING")
    health  = analysis.get("health_score", 100)
    risk    = analysis.get("risk_score", 0)
    temp    = tel.get("temperature", 0)
    current = tel.get("current", 0)

    if status == "CRITICAL":
        line2 = "!! CRITICAL ALERT"
    elif status == "WARNING":
        line2 = ">> WARNING ACTIVE"
    elif status == "LEARNING":
        line2 = f"LEARNING {analysis.get('learning_progress', 0)}%"
    else:
        line2 = "SYSTEM HEALTHY"

    return {
        "line1": f"Health:{health:.0f}% Risk:{risk:.0f}%",
        "line2": line2,
        "line3": f"T:{temp:.1f}C I:{current:.2f}A",
        "line4": analysis.get("primary_explanation", "")[:20],
    }


# ─── GET /api/events — Event timeline ────────────────────────────────────────
@router.get("/api/events")
def get_events():
    return get_recent_events(50)


# ─── GET /api/history — Historical trends ────────────────────────────────────
@router.get("/api/history")
def get_history():
    return get_latest_telemetry(n=200)
