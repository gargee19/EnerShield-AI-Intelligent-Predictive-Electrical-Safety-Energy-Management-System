"""
EnerShield OS — SQLite Database Layer
"""
import sqlite3
import json
import time
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "enershield.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS telemetry (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp REAL NOT NULL,
            temperature REAL,
            gas_level REAL,
            current REAL,
            voltage REAL,
            vibration INTEGER,
            relay_motor INTEGER,
            relay_fan INTEGER,
            relay_bulb INTEGER
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS relay_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp REAL NOT NULL,
            relay_motor INTEGER DEFAULT 1,
            relay_fan INTEGER DEFAULT 1,
            relay_bulb INTEGER DEFAULT 1,
            source TEXT DEFAULT 'auto'
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp REAL NOT NULL,
            event_type TEXT,
            severity TEXT,
            message TEXT,
            details TEXT
        )
    """)

    # Insert default relay state
    c.execute("SELECT COUNT(*) FROM relay_commands")
    if c.fetchone()[0] == 0:
        c.execute("""
            INSERT INTO relay_commands (timestamp, relay_motor, relay_fan, relay_bulb, source)
            VALUES (?, 1, 1, 1, 'init')
        """, (time.time(),))

    conn.commit()
    conn.close()
    print("[DB] EnerShield database initialized.")


def insert_telemetry(data: dict):
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        INSERT INTO telemetry 
        (timestamp, temperature, gas_level, current, voltage, vibration, relay_motor, relay_fan, relay_bulb)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        time.time(),
        data.get("temperature"),
        data.get("gas_level"),
        data.get("current"),
        data.get("voltage"),
        data.get("vibration"),
        data.get("relay_motor", 1),
        data.get("relay_fan", 1),
        data.get("relay_bulb", 1),
    ))
    conn.commit()
    conn.close()


def get_latest_telemetry(n=100):
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        SELECT * FROM telemetry ORDER BY timestamp DESC LIMIT ?
    """, (n,))
    rows = c.fetchall()
    conn.close()
    return [dict(r) for r in reversed(rows)]


def get_relay_commands():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM relay_commands ORDER BY id DESC LIMIT 1")
    row = c.fetchone()
    conn.close()
    return dict(row) if row else {"relay_motor": 1, "relay_fan": 1, "relay_bulb": 1}


def set_relay_commands(motor: int, fan: int, bulb: int, source: str = "dashboard"):
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        INSERT INTO relay_commands (timestamp, relay_motor, relay_fan, relay_bulb, source)
        VALUES (?, ?, ?, ?, ?)
    """, (time.time(), motor, fan, bulb, source))
    conn.commit()
    conn.close()


def log_event(event_type: str, severity: str, message: str, details: dict = None):
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        INSERT INTO events (timestamp, event_type, severity, message, details)
        VALUES (?, ?, ?, ?, ?)
    """, (time.time(), event_type, severity, message, json.dumps(details or {})))
    conn.commit()
    conn.close()


def get_recent_events(n=50):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM events ORDER BY timestamp DESC LIMIT ?", (n,))
    rows = c.fetchall()
    conn.close()
    return [dict(r) for r in rows]
