"""
ENERSHIELD OS — FastAPI Backend
AI-Powered Predictive Infrastructure Operating System
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import time
import uvicorn

from api.routes import router
from db.database import init_db

app = FastAPI(
    title="EnerShield OS",
    description="AI-Powered Predictive Infrastructure Operating System",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

@app.on_event("startup")
async def startup():
    init_db()
    print("EnerShield OS Backend — ONLINE")

@app.get("/health")
def health_check():
    return {
        "status": "operational",
        "system": "EnerShield OS",
        "timestamp": time.time()
    }

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
