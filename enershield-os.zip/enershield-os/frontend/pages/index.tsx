import { useState, useEffect, useRef } from 'react'
import Head from 'next/head'
import {
  LineChart, Line, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine
} from 'recharts'
import { useLiveData, setRelays, fetchEvents } from '../hooks/useLiveData'

// ─── Color helpers ────────────────────────────────────────────────────────────
const STATUS_COLORS: Record<string, string> = {
  HEALTHY:  '#00ff88',
  LEARNING: '#00d4ff',
  CAUTION:  '#f59e0b',
  WARNING:  '#ffaa00',
  CRITICAL: '#ff2d55',
}
const STATUS_BG: Record<string, string> = {
  HEALTHY:  'rgba(0,255,136,0.08)',
  LEARNING: 'rgba(0,212,255,0.08)',
  CAUTION:  'rgba(245,158,11,0.08)',
  WARNING:  'rgba(255,170,0,0.10)',
  CRITICAL: 'rgba(255,45,85,0.14)',
}

function statusColor(s: string) { return STATUS_COLORS[s] || '#c8e6ff' }
function statusBg(s: string)    { return STATUS_BG[s]     || 'transparent' }

// ─── Reusable Components ─────────────────────────────────────────────────────

function CyberCard({ children, className = '', glow = 'blue' }: any) {
  const glowClass = {
    green:  'card-glow-green',
    amber:  'card-glow-amber',
    red:    'card-glow-red',
    blue:   'card-glow-blue',
    none:   '',
  }[glow] || ''
  return (
    <div className={`cyber-card p-4 ${glowClass} ${className}`}>
      {children}
    </div>
  )
}

function SectionLabel({ children }: any) {
  return (
    <div className="flex items-center gap-2 mb-3">
      <div className="w-1 h-4 bg-cyan-400" />
      <span className="terminal-text text-cyan-400 text-xs uppercase tracking-widest">{children}</span>
    </div>
  )
}

function GaugeMeter({ value, label, color, max = 100 }: any) {
  const pct = Math.min(100, Math.max(0, value))
  const angle = -135 + (270 * pct / max)
  const r = 52, cx = 60, cy = 64
  const rad = (a: number) => (a * Math.PI) / 180
  const startAngle = -135
  const endAngle   = startAngle + (270 * pct / max)
  const x1 = cx + r * Math.cos(rad(startAngle))
  const y1 = cy + r * Math.sin(rad(startAngle))
  const x2 = cx + r * Math.cos(rad(endAngle))
  const y2 = cy + r * Math.sin(rad(endAngle))
  const large = endAngle - startAngle > 180 ? 1 : 0

  return (
    <div className="flex flex-col items-center">
      <svg width="120" height="80" viewBox="0 0 120 90">
        {/* Track */}
        <path
          d={`M ${cx + r * Math.cos(rad(-135))} ${cy + r * Math.sin(rad(-135))} A ${r} ${r} 0 1 1 ${cx + r * Math.cos(rad(135))} ${cy + r * Math.sin(rad(135))}`}
          fill="none" stroke="#1a3a6e" strokeWidth="8" strokeLinecap="round"
        />
        {/* Fill */}
        {pct > 0 && (
          <path
            d={`M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`}
            fill="none" stroke={color} strokeWidth="8" strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 6px ${color}88)` }}
          />
        )}
        <text x={cx} y={cy + 6} textAnchor="middle" fill={color}
          fontSize="16" fontFamily="Rajdhani" fontWeight="700">
          {Math.round(pct)}
        </text>
        <text x={cx} y={cy + 20} textAnchor="middle" fill="#4a6fa5"
          fontSize="9" fontFamily="Share Tech Mono">
          {label}
        </text>
      </svg>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const color = statusColor(status)
  return (
    <span
      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-sm text-xs font-bold tracking-widest"
      style={{ color, background: statusBg(status), border: `1px solid ${color}33` }}
    >
      <span className="pulse-dot" style={{ background: color }} />
      {status}
    </span>
  )
}

function RelayToggle({ label, active, onToggle, disabled }: any) {
  return (
    <button
      onClick={onToggle}
      disabled={disabled}
      className="flex items-center justify-between w-full px-3 py-2 mb-2 rounded-sm transition-all"
      style={{
        background: active ? 'rgba(0,255,136,0.08)' : 'rgba(255,45,85,0.08)',
        border: `1px solid ${active ? '#00ff8844' : '#ff2d5544'}`,
        color: active ? '#00ff88' : '#ff2d55',
        opacity: disabled ? 0.5 : 1,
        cursor: disabled ? 'not-allowed' : 'pointer',
      }}
    >
      <span className="terminal-text text-xs">{label}</span>
      <span className="text-xs font-bold tracking-widest">{active ? '● ON' : '○ OFF'}</span>
    </button>
  )
}

function MiniMetric({ label, value, unit, color = '#c8e6ff', warn = false }: any) {
  return (
    <div className="cyber-card p-3 flex flex-col gap-1">
      <span className="terminal-text text-xs" style={{ color: '#4a6fa5' }}>{label}</span>
      <span className="font-display font-bold text-xl" style={{ color: warn ? '#ffaa00' : color }}>
        {value}<span className="text-xs ml-1 text-cyber-muted">{unit}</span>
      </span>
    </div>
  )
}

// ─── Custom Chart Tooltip ────────────────────────────────────────────────────
function CyberTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null
  return (
    <div className="cyber-card px-3 py-2 text-xs terminal-text" style={{ borderColor: '#00d4ff44' }}>
      {payload.map((p: any, i: number) => (
        <div key={i} style={{ color: p.color }}>
          {p.name}: {typeof p.value === 'number' ? p.value.toFixed(3) : p.value}
        </div>
      ))}
    </div>
  )
}

// ─── Event Timeline ──────────────────────────────────────────────────────────
function EventTimeline({ events }: { events: any[] }) {
  const sevColor: Record<string, string> = {
    CRITICAL: '#ff2d55',
    WARNING:  '#ffaa00',
    INFO:     '#00d4ff',
  }
  return (
    <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
      {events.length === 0 && (
        <div className="terminal-text text-cyber-muted text-xs">No events recorded.</div>
      )}
      {events.map((e: any, i: number) => (
        <div key={i} className="flex items-start gap-2 text-xs terminal-text">
          <span style={{ color: sevColor[e.severity] || '#c8e6ff', minWidth: 60 }}>
            [{e.severity}]
          </span>
          <span className="text-cyber-text truncate">{e.message}</span>
          <span className="text-cyber-muted ml-auto whitespace-nowrap">
            {new Date(e.timestamp * 1000).toLocaleTimeString()}
          </span>
        </div>
      ))}
    </div>
  )
}

// ─── Main Dashboard ──────────────────────────────────────────────────────────
export default function Dashboard() {
  const { data, error, connected } = useLiveData(1000)
  const [events, setEvents] = useState<any[]>([])
  const [relayOverride, setRelayOverride] = useState({ motor: 1, fan: 1, bulb: 1 })
  const eventsRef = useRef<any[]>([])

  useEffect(() => {
    const load = async () => {
      try {
        const ev = await fetchEvents()
        eventsRef.current = ev
        setEvents(ev)
      } catch {}
    }
    load()
    const iv = setInterval(load, 3000)
    return () => clearInterval(iv)
  }, [])

  // Sync relay override from AI
  useEffect(() => {
    if (data?.ai?.relay_commands) {
      setRelayOverride({
        motor: data.ai.relay_commands.motor,
        fan: data.ai.relay_commands.fan,
        bulb: data.ai.relay_commands.bulb,
      })
    }
  }, [data?.ai?.relay_commands])

  const tel    = data?.telemetry
  const ai     = data?.ai
  const hist   = data?.history || []
  const status = ai?.overall_status || 'LEARNING'
  const autonomous = ai?.autonomous_protection || false

  const handleRelayToggle = async (key: 'motor' | 'fan' | 'bulb') => {
    const next = { ...relayOverride, [key]: relayOverride[key] ? 0 : 1 }
    setRelayOverride(next)
    await setRelays(next.motor, next.fan, next.bulb)
  }

  // Chart data
  const chartData = hist.map((h, i) => ({
    t:    i,
    current:     +(h.current || 0).toFixed(3),
    voltage:     +(h.voltage  || 0).toFixed(1),
    temperature: +(h.temperature || 0).toFixed(1),
    gas:         +(h.gas_level || 0).toFixed(0),
    vibration:   h.vibration || 0,
  }))

  const eff = ai?.electrical_efficiency
  const ef_pf = eff?.estimated_pf || 0
  const ef_label = eff?.efficiency_label || '–'

  return (
    <>
      <Head>
        <title>EnerShield OS — AI Infrastructure Command</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@400;500;600;700&family=Exo+2:wght@300;400;500;600&display=swap" rel="stylesheet" />
      </Head>

      <div className="relative z-10 min-h-screen p-4" style={{ background: '#030712' }}>

        {/* ── HEADER ─────────────────────────────────────────────────────── */}
        <header className="cyber-card mb-4 px-6 py-3 flex items-center justify-between"
          style={{ borderColor: `${statusColor(status)}44` }}>
          <div className="flex items-center gap-4">
            <div>
              <div className="font-display font-bold text-2xl tracking-widest text-white glow-text"
                style={{ color: statusColor(status), textShadow: `0 0 20px ${statusColor(status)}88` }}>
                ENERSHIELD OS
              </div>
              <div className="terminal-text text-xs text-cyber-muted">
                AI PREDICTIVE INFRASTRUCTURE OPERATING SYSTEM
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="text-center">
              <div className="terminal-text text-xs text-cyber-muted mb-1">SYSTEM STATUS</div>
              <StatusBadge status={status} />
            </div>
            <div className="text-center">
              <div className="terminal-text text-xs text-cyber-muted mb-1">BACKEND</div>
              <span className={`terminal-text text-xs font-bold ${connected ? 'text-green-400' : 'text-red-400'}`}>
                {connected ? '● CONNECTED' : '○ OFFLINE'}
              </span>
            </div>
            <div className="text-center">
              <div className="terminal-text text-xs text-cyber-muted mb-1">SAMPLES</div>
              <span className="terminal-text text-xs text-cyan-400 font-bold">
                {ai?.sample_count || 0}
              </span>
            </div>
            <div className="text-center">
              <div className="terminal-text text-xs text-cyber-muted mb-1">TIME</div>
              <span className="terminal-text text-xs text-cyber-text">
                {new Date().toLocaleTimeString()}
              </span>
            </div>
          </div>
        </header>

        {/* ── AUTONOMOUS PROTECTION BANNER ───────────────────────────────── */}
        {autonomous && (
          <div className="cyber-card mb-4 px-6 py-3 text-center animate-pulse"
            style={{ background: 'rgba(255,45,85,0.12)', borderColor: '#ff2d55' }}>
            <span className="font-display font-bold text-lg text-red-400 tracking-widest glow-text">
              ⚠ AUTONOMOUS PROTECTION ACTIVATED — {ai?.relay_reason}
            </span>
          </div>
        )}

        {/* ── ROW 1: GAUGES + LIVE METRICS ───────────────────────────────── */}
        <div className="grid grid-cols-12 gap-3 mb-3">

          {/* Health + Risk Gauges */}
          <div className="col-span-3 cyber-card p-4" style={{ borderColor: `${statusColor(status)}33` }}>
            <SectionLabel>Infrastructure Health</SectionLabel>
            <div className="flex justify-around">
              <GaugeMeter
                value={ai?.health_score ?? 100}
                label="HEALTH %"
                color={ai?.health_score > 70 ? '#00ff88' : ai?.health_score > 40 ? '#ffaa00' : '#ff2d55'}
              />
              <GaugeMeter
                value={ai?.risk_score ?? 0}
                label="RISK %"
                color={ai?.risk_score < 20 ? '#00ff88' : ai?.risk_score < 50 ? '#ffaa00' : '#ff2d55'}
              />
            </div>
            <div className="mt-2 text-center">
              <div className="terminal-text text-xs text-cyber-muted">
                Learning: {ai?.learning_progress || 0}% complete
              </div>
              <div className="w-full bg-cyber-border rounded mt-1 h-1.5">
                <div
                  className="h-1.5 rounded transition-all"
                  style={{ width: `${ai?.learning_progress || 0}%`, background: '#00d4ff' }}
                />
              </div>
            </div>
          </div>

          {/* Live Sensor Metrics */}
          <div className="col-span-6 grid grid-cols-3 gap-2">
            <MiniMetric
              label="TEMPERATURE"
              value={tel?.temperature?.toFixed(1) ?? '–'}
              unit="°C"
              color={tel?.temperature > 50 ? '#ff2d55' : tel?.temperature > 38 ? '#ffaa00' : '#00ff88'}
              warn={tel?.temperature > 38}
            />
            <MiniMetric
              label="CURRENT"
              value={tel?.current?.toFixed(3) ?? '–'}
              unit="A"
              color={tel?.current > 4 ? '#ff2d55' : tel?.current > 2 ? '#ffaa00' : '#00d4ff'}
              warn={tel?.current > 2}
            />
            <MiniMetric
              label="VOLTAGE"
              value={tel?.voltage?.toFixed(1) ?? '–'}
              unit="V"
              color="#c8e6ff"
            />
            <MiniMetric
              label="GAS LEVEL"
              value={tel?.gas_level?.toFixed(0) ?? '–'}
              unit="ADC"
              color={tel?.gas_level > 600 ? '#ff2d55' : tel?.gas_level > 300 ? '#ffaa00' : '#00ff88'}
              warn={tel?.gas_level > 300}
            />
            <MiniMetric
              label="VIBRATION"
              value={tel?.vibration ?? '–'}
              unit=""
              color={tel?.vibration ? '#ffaa00' : '#00ff88'}
              warn={!!tel?.vibration}
            />
            <MiniMetric
              label="EST. POWER FACTOR"
              value={ef_pf.toFixed(3)}
              unit=""
              color={ef_pf >= 0.9 ? '#00ff88' : ef_pf >= 0.8 ? '#ffaa00' : '#ff2d55'}
            />
          </div>

          {/* Relay Control */}
          <div className="col-span-3 cyber-card p-4">
            <SectionLabel>Relay Control</SectionLabel>
            <RelayToggle
              label="MOTOR RELAY"
              active={relayOverride.motor}
              onToggle={() => handleRelayToggle('motor')}
              disabled={autonomous}
            />
            <RelayToggle
              label="FAN RELAY"
              active={relayOverride.fan}
              onToggle={() => handleRelayToggle('fan')}
              disabled={autonomous}
            />
            <RelayToggle
              label="BULB RELAY"
              active={relayOverride.bulb}
              onToggle={() => handleRelayToggle('bulb')}
              disabled={autonomous}
            />
            {autonomous && (
              <div className="terminal-text text-xs text-red-400 mt-2 text-center">
                AI AUTONOMOUS LOCK ACTIVE
              </div>
            )}
          </div>
        </div>

        {/* ── ROW 2: CHARTS ──────────────────────────────────────────────── */}
        <div className="grid grid-cols-12 gap-3 mb-3">

          {/* Current Chart */}
          <div className="col-span-4 cyber-card p-4">
            <SectionLabel>Current Consumption</SectionLabel>
            <ResponsiveContainer width="100%" height={130}>
              <AreaChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="gradI" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#00d4ff" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#00d4ff" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a3a6e44" />
                <XAxis dataKey="t" hide />
                <YAxis tick={{ fill: '#4a6fa5', fontSize: 10 }} />
                <Tooltip content={<CyberTooltip />} />
                <ReferenceLine y={4.5} stroke="#ff2d5588" strokeDasharray="4 4" label={{ value: 'OVERLOAD', fill: '#ff2d55', fontSize: 10 }} />
                <Area type="monotone" dataKey="current" name="Current (A)"
                  stroke="#00d4ff" fill="url(#gradI)" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Vibration Chart */}
          <div className="col-span-4 cyber-card p-4">
            <SectionLabel>Vibration Pattern</SectionLabel>
            <ResponsiveContainer width="100%" height={130}>
              <AreaChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="gradV" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#a855f7" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a3a6e44" />
                <XAxis dataKey="t" hide />
                <YAxis tick={{ fill: '#4a6fa5', fontSize: 10 }} domain={[0, 1.5]} />
                <Tooltip content={<CyberTooltip />} />
                <Area type="monotone" dataKey="vibration" name="Vibration"
                  stroke="#a855f7" fill="url(#gradV)" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
            <div className="terminal-text text-xs text-cyber-muted mt-1">
              Baseline: {ai?.baselines?.vibration_mean?.toFixed(2) ?? '–'} | Z-score: {ai?.components?.vibration?.zscore?.toFixed(2) ?? '–'}
            </div>
          </div>

          {/* Temperature + Gas Chart */}
          <div className="col-span-4 cyber-card p-4">
            <SectionLabel>Temperature & Gas</SectionLabel>
            <ResponsiveContainer width="100%" height={130}>
              <LineChart data={chartData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a3a6e44" />
                <XAxis dataKey="t" hide />
                <YAxis tick={{ fill: '#4a6fa5', fontSize: 10 }} yAxisId="temp" />
                <YAxis tick={{ fill: '#4a6fa5', fontSize: 10 }} yAxisId="gas" orientation="right" />
                <Tooltip content={<CyberTooltip />} />
                <Line yAxisId="temp" type="monotone" dataKey="temperature" name="Temp (°C)"
                  stroke="#ff6b35" strokeWidth={2} dot={false} />
                <Line yAxisId="gas" type="monotone" dataKey="gas" name="Gas"
                  stroke="#00ff88" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-1">
              <span className="terminal-text text-xs" style={{ color: '#ff6b35' }}>■ Temperature</span>
              <span className="terminal-text text-xs" style={{ color: '#00ff88' }}>■ Gas Level</span>
            </div>
          </div>
        </div>

        {/* ── ROW 3: AI + MAINTENANCE + EVENTS ───────────────────────────── */}
        <div className="grid grid-cols-12 gap-3 mb-3">

          {/* AI Explanation Engine */}
          <div className="col-span-5 cyber-card p-4"
            style={{ borderColor: `${statusColor(status)}33`, background: statusBg(status) }}>
            <SectionLabel>AI Explanation Engine</SectionLabel>

            <div className="mb-3 p-3 rounded-sm"
              style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid #1a3a6e' }}>
              <div className="terminal-text text-xs text-cyan-400 mb-2">PRIMARY DIAGNOSIS</div>
              <div className="font-display text-sm text-white leading-relaxed">
                {ai?.primary_explanation || 'Awaiting telemetry data...'}
              </div>
            </div>

            {ai?.all_explanations && ai.all_explanations.length > 1 && (
              <div className="space-y-1">
                {ai.all_explanations.slice(1).map((exp, i) => (
                  <div key={i} className="terminal-text text-xs text-cyber-muted flex gap-2">
                    <span className="text-amber-400">›</span>
                    <span>{exp}</span>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-3 grid grid-cols-5 gap-1">
              {['vibration', 'current', 'temperature', 'gas', 'voltage'].map(key => {
                const comp = ai?.components?.[key as keyof typeof ai.components] as any
                const s = comp?.status || 'normal'
                const color = s === 'critical' ? '#ff2d55' : s === 'warning' ? '#ffaa00' : '#00ff88'
                return (
                  <div key={key} className="text-center">
                    <div className="w-2 h-2 rounded-full mx-auto mb-1" style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
                    <div className="terminal-text" style={{ fontSize: '9px', color: '#4a6fa5' }}>{key.toUpperCase().slice(0,4)}</div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Predictive Maintenance */}
          <div className="col-span-4 cyber-card p-4">
            <SectionLabel>Predictive Maintenance</SectionLabel>
            {(!ai?.maintenance_flags || ai.maintenance_flags.length === 0) ? (
              <div className="flex items-center gap-2 p-3 rounded-sm"
                style={{ background: 'rgba(0,255,136,0.06)', border: '1px solid #00ff8833' }}>
                <span className="text-green-400 text-lg">✓</span>
                <span className="terminal-text text-xs text-green-400">All systems nominal. No maintenance required.</span>
              </div>
            ) : (
              <div className="space-y-2">
                {ai.maintenance_flags.map((flag, i) => {
                  const pc = flag.priority === 'CRITICAL' ? '#ff2d55' : '#ffaa00'
                  return (
                    <div key={i} className="p-2 rounded-sm"
                      style={{ background: `${pc}0f`, border: `1px solid ${pc}33` }}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-display font-bold text-xs" style={{ color: pc }}>{flag.component}</span>
                        <span className="terminal-text text-xs" style={{ color: pc }}>[{flag.priority}]</span>
                      </div>
                      <div className="terminal-text text-xs text-cyber-text mb-1">{flag.issue}</div>
                      <div className="terminal-text text-xs text-cyber-muted">→ {flag.action}</div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          {/* Electrical Efficiency */}
          <div className="col-span-3 cyber-card p-4">
            <SectionLabel>Electrical Efficiency</SectionLabel>
            <div className="text-center mb-3">
              <div className="font-display font-bold text-4xl"
                style={{ color: ef_pf >= 0.9 ? '#00ff88' : ef_pf >= 0.8 ? '#ffaa00' : '#ff2d55' }}>
                {ef_pf.toFixed(2)}
              </div>
              <div className="terminal-text text-xs text-cyber-muted">Estimated Power Factor</div>
              <div className="terminal-text text-xs font-bold mt-1"
                style={{ color: ef_pf >= 0.9 ? '#00ff88' : ef_pf >= 0.8 ? '#ffaa00' : '#ff2d55' }}>
                {ef_label}
              </div>
            </div>
            <div className="space-y-2 text-xs terminal-text">
              <div className="flex justify-between">
                <span className="text-cyber-muted">Apparent Power</span>
                <span className="text-cyan-400">{eff?.apparent_power_va?.toFixed(1) || '–'} VA</span>
              </div>
              <div className="flex justify-between">
                <span className="text-cyber-muted">Active Power</span>
                <span className="text-cyan-400">{eff?.estimated_active_power_w?.toFixed(1) || '–'} W</span>
              </div>
              <div className="flex justify-between">
                <span className="text-cyber-muted">V Stability</span>
                <span style={{ color: '#a855f7' }}>{((eff?.v_stability || 0) * 100).toFixed(0)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-cyber-muted">I Stability</span>
                <span style={{ color: '#a855f7' }}>{((eff?.i_stability || 0) * 100).toFixed(0)}%</span>
              </div>
            </div>
            <div className="terminal-text text-xs text-cyber-muted mt-3 text-center italic">
              Estimated Electrical Efficiency
            </div>
          </div>
        </div>

        {/* ── ROW 4: COMPONENT STATUS + EVENTS ───────────────────────────── */}
        <div className="grid grid-cols-12 gap-3">

          {/* Anomaly Status Grid */}
          <div className="col-span-4 cyber-card p-4">
            <SectionLabel>Component Anomaly Status</SectionLabel>
            <div className="space-y-2">
              {[
                { key: 'vibration',   label: 'MOTOR VIBRATION',    icon: '⚙' },
                { key: 'current',     label: 'CURRENT DRAW',        icon: '⚡' },
                { key: 'temperature', label: 'THERMAL STATE',       icon: '🌡' },
                { key: 'gas',         label: 'GAS ENVIRONMENT',     icon: '💨' },
                { key: 'voltage',     label: 'VOLTAGE INTEGRITY',   icon: '〰' },
              ].map(({ key, label, icon }) => {
                const comp = ai?.components?.[key as keyof typeof ai.components] as any
                const s    = comp?.status || 'normal'
                const color = s === 'critical' ? '#ff2d55' : s === 'warning' ? '#ffaa00' : '#00ff88'
                const val  = comp?.current_value
                return (
                  <div key={key} className="flex items-center justify-between px-2 py-1.5 rounded-sm"
                    style={{ background: `${color}0a`, border: `1px solid ${color}22` }}>
                    <span className="terminal-text text-xs" style={{ color: '#4a6fa5' }}>
                      {icon} {label}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="terminal-text text-xs text-cyber-muted">
                        {val !== undefined ? val : '–'}
                      </span>
                      <span className="terminal-text text-xs font-bold uppercase"
                        style={{ color }}>{s}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Anomaly List */}
          <div className="col-span-3 cyber-card p-4">
            <SectionLabel>Active Anomalies</SectionLabel>
            {(!ai?.anomalies || ai.anomalies.length === 0) ? (
              <div className="terminal-text text-xs text-green-400 text-center py-4">
                ✓ No active anomalies detected
              </div>
            ) : (
              <div className="space-y-1">
                {ai.anomalies.map((a, i) => (
                  <div key={i} className="flex items-center gap-2 px-2 py-1.5 rounded-sm"
                    style={{ background: 'rgba(255,45,85,0.08)', border: '1px solid #ff2d5533' }}>
                    <span className="text-red-400 text-xs">▲</span>
                    <span className="terminal-text text-xs text-red-400 font-bold">{a.replace(/_/g, ' ')}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Event Timeline */}
          <div className="col-span-5 cyber-card p-4">
            <SectionLabel>Event Timeline</SectionLabel>
            <EventTimeline events={events} />
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-4 terminal-text text-xs text-cyber-muted">
          ENERSHIELD OS v1.0 — AI PREDICTIVE INFRASTRUCTURE OPERATING SYSTEM — REST POLLING @ 1Hz
        </div>
      </div>
    </>
  )
}
