/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        mono: ['Share Tech Mono', 'Courier New', 'monospace'],
        display: ['Rajdhani', 'sans-serif'],
        body: ['Exo 2', 'sans-serif'],
      },
      colors: {
        cyber: {
          bg:      '#030712',
          surface: '#0a1628',
          card:    '#0f1f3d',
          border:  '#1a3a6e',
          glow:    '#00d4ff',
          accent:  '#0ea5e9',
          green:   '#00ff88',
          amber:   '#ffaa00',
          red:     '#ff2d55',
          purple:  '#a855f7',
          text:    '#c8e6ff',
          muted:   '#4a6fa5',
        }
      },
      animation: {
        'pulse-slow': 'pulse 3s ease-in-out infinite',
        'scan': 'scan 4s linear infinite',
        'glow-pulse': 'glowPulse 2s ease-in-out infinite',
        'flicker': 'flicker 5s linear infinite',
      },
      keyframes: {
        scan: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100vh)' },
        },
        glowPulse: {
          '0%, 100%': { boxShadow: '0 0 10px #00d4ff44, 0 0 30px #00d4ff22' },
          '50%': { boxShadow: '0 0 20px #00d4ff88, 0 0 60px #00d4ff44' },
        },
        flicker: {
          '0%, 98%, 100%': { opacity: '1' },
          '99%': { opacity: '0.8' },
        }
      }
    },
  },
  plugins: [],
}
