import { useState, useEffect, useCallback } from 'react'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://10.184.175.22:8000'

export interface TelemetryData {
  temperature: number
  gas_level: number
  current: number
  voltage: number
  vibration: number
  relay_motor: number
  relay_fan: number
  relay_bulb: number
  timestamp: number
}

export interface AIAnalysis {
  overall_status: string
  health_score: number
  risk_score: number
  anomalies: string[]
  primary_explanation: string
  all_explanations: string[]
  learning_complete: boolean
  learning_progress: number
  sample_count: number
  components: {
    vibration: { status: string; zscore: number; baseline_mean: number; current_value: number }
    current: { status: string; zscore: number; baseline_mean: number; current_value: number }
    temperature: { status: string; current_value: number }
    gas: { status: string; current_value: number }
    voltage: { status: string; current_value: number }
  }
  relay_commands: { motor: number; fan: number; bulb: number }
  autonomous_protection: boolean
  relay_reason: string
  electrical_efficiency: {
    estimated_pf: number
    apparent_power_va: number
    estimated_active_power_w: number
    efficiency_label: string
    v_stability: number
    i_stability: number
  }
  maintenance_flags: Array<{ component: string; issue: string; priority: string; action: string }>
  baselines: { vibration_mean: number; current_mean: number; temp_mean: number; gas_mean: number }
}

export interface LiveData {
  telemetry: TelemetryData
  ai: AIAnalysis
  history: TelemetryData[]
  timestamp: number
}

export function useLiveData(intervalMs = 1000) {
  const [data, setData] = useState<LiveData | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [connected, setConnected] = useState(false)

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch(`${API_URL}/api/live`, { cache: 'no-store' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const json = await res.json()
      setData(json)
      setConnected(true)
      setError(null)
    } catch (e: any) {
      setError(e.message || 'Connection failed')
      setConnected(false)
    }
  }, [])

  useEffect(() => {
    fetchData()
    const interval = setInterval(fetchData, intervalMs)
    return () => clearInterval(interval)
  }, [fetchData, intervalMs])

  return { data, error, connected }
}

export async function setRelays(motor: number, fan: number, bulb: number) {
  await fetch(`${API_URL}/api/relay`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ relay_motor: motor, relay_fan: fan, relay_bulb: bulb }),
  })
}

export async function fetchEvents() {
  const res = await fetch(`${API_URL}/api/events`)
  return res.json()
}
